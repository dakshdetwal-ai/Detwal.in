DETwal project structure

FRONTEND
- frontend/home/            Main DETwal homepage
- frontend/signup/          Signup/login UI
- frontend/journal/         Free Trading Journal
- frontend/news-trading/    Paid News Trading product
- frontend/community/       Free trader community
- frontend/strategies-store/ Strategies Marketplace
- frontend/terms/           Terms of Use
- frontend/privacy/         Privacy Policy
- frontend/shared/           Shared CSS, JS and assets

BACKEND
- backend/app/main.py       FastAPI entry point
- backend/app/routes/       API endpoints
- backend/app/models/       Database models
- backend/app/schemas/      Request/response schemas
- backend/app/services/     Business logic
- backend/app/auth/         Password/JWT authentication
- backend/app/database/     Database connection/models
- backend/data/             Local development data
- backend/tests/            Backend tests

WHERE TO WRITE CODE
- Page HTML -> that product's index.html
- Page design -> that product's style.css
- Page interactions -> that product's script.js
- Product static/demo data -> that product's data.js
- Shared design -> frontend/shared/css/
- Shared frontend functions -> frontend/shared/js/
- Python API -> backend/app/routes/
- Authentication logic -> backend/app/auth/ and services/auth_service.py
- Database models -> backend/app/models/
- Database connection -> backend/app/database/
- General backend startup/config -> backend/app/main.py and config.py

For now, all files are intentionally EMPTY.
